package BookLibraryApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLibraryApp {

    public static void main(String[] args) {
        SpringApplication.run(BookLibraryApp.class, args);
    }
}
